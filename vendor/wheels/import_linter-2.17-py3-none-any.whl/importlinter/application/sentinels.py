class NotSupplied:
    pass
