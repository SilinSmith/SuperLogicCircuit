"""Data models for mutmut."""
